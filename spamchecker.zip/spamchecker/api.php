<?php
require_once 'config.php';

// Enable CORS for cross-origin requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Read JSON input once and store it
$json_input = file_get_contents('php://input');

// Remove BOM if present
$json_input = preg_replace('/^\xEF\xBB\xBF/', '', $json_input);

// Try to decode JSON
$json_data = json_decode($json_input, true);

// Check for JSON errors
$json_error = json_last_error();
if ($json_error !== JSON_ERROR_NONE && !empty($json_input)) {
    logActivity('API Error', 'JSON parse error: ' . json_last_error_msg() . ', Input: ' . substr($json_input, 0, 200));
    // Try to fix common JSON issues
    $json_input = trim($json_input);
    $json_data = json_decode($json_input, true);
}

// Log incoming request for debugging
logActivity('API Request', 'Method: ' . $_SERVER['REQUEST_METHOD'] . ', JSON valid: ' . ($json_error === JSON_ERROR_NONE ? 'yes' : 'no') . ', Action from JSON: ' . ($json_data['action'] ?? 'none'));

// Get action from GET, POST, or JSON body
$action = $_GET['action'] ?? $_POST['action'] ?? ($json_data['action'] ?? '');

// If still no action, return error
if (empty($action)) {
    logActivity('API Error', 'No action found. Method: ' . $_SERVER['REQUEST_METHOD'] . ', GET: ' . ($_GET['action'] ?? 'none') . ', POST: ' . ($_POST['action'] ?? 'none') . ', JSON action: ' . ($json_data['action'] ?? 'none'));
    jsonResponse(['error' => 'Ugyldig handling - ingen action angivet. Metode: ' . $_SERVER['REQUEST_METHOD']], 400);
}

try {
    switch ($action) {
        case 'analyze':
            analyzeMessageEndpoint();
            break;
        
        case 'reports':
            getReportsEndpoint();
            break;
        
        case 'report':
            saveReportEndpoint();
            break;
        
        default:
            jsonResponse(['error' => 'Ugyldig handling'], 400);
    }
} catch (Exception $e) {
    logActivity('API Error', $e->getMessage());
    jsonResponse(['error' => 'Der opstod en fejl: ' . $e->getMessage()], 500);
}

function analyzeMessageEndpoint() {
    global $json_data;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Kun POST metoder er tilladt'], 405);
    }
    
    $input = $json_data;
    
    if (!$input || !isset($input['text']) || empty(trim($input['text']))) {
        jsonResponse(['error' => 'Tekst mangler'], 400);
    }
    
    $text = trim($input['text']);
    $type = $input['type'] ?? 'email';
    
    // Validate type
    if (!in_array($type, ['email', 'sms'])) {
        $type = 'email';
    }
    
    // Analyze the message
    $results = analyzeMessage($text, $type);
    
    // Save report
    $report_id = saveReport($text, $type, $results);
    
    // Log activity
    logActivity('Analyse udført', "Type: $type, Score: {$results['score']}, ID: $report_id");
    
    // Return results
    jsonResponse([
        'success' => true,
        'report_id' => $report_id,
        'results' => $results
    ]);
}

function getReportsEndpoint() {
    $limit = intval($_GET['limit'] ?? 50);
    $limit = min(100, max(1, $limit)); // Between 1 and 100
    
    $reports = getReports($limit);
    
    // Remove full text from list view for privacy
    $public_reports = array_map(function($report) {
        return [
            'id' => $report['id'],
            'timestamp' => $report['timestamp'],
            'type' => $report['type'],
            'text_preview' => mb_substr($report['text'], 0, 100) . '...',
            'score' => $report['results']['score'],
            'verdict' => $report['results']['verdict'],
            'verdict_class' => $report['results']['verdict_class'],
            'warning_count' => count($report['results']['warnings'])
        ];
    }, $reports);
    
    jsonResponse([
        'success' => true,
        'reports' => $public_reports,
        'total' => count($public_reports)
    ]);
}

function saveReportEndpoint() {
    global $json_data;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['error' => 'Kun POST metoder er tilladt'], 405);
    }
    
    $input = $json_data;
    
    if (!$input || !isset($input['text']) || empty(trim($input['text']))) {
        jsonResponse(['error' => 'Tekst mangler'], 400);
    }
    
    $text = trim($input['text']);
    $type = $input['type'] ?? 'email';
    $comment = $input['comment'] ?? '';
    
    if (!in_array($type, ['email', 'sms'])) {
        $type = 'email';
    }
    
    // Analyze the message
    $results = analyzeMessage($text, $type);
    
    // Add user comment if provided
    if (!empty($comment)) {
        $results['user_comment'] = $comment;
    }
    
    // Save report
    $report_id = saveReport($text, $type, $results);
    
    // Log activity
    logActivity('Rapport gemt', "Type: $type, Score: {$results['score']}, ID: $report_id");
    
    jsonResponse([
        'success' => true,
        'message' => 'Rapport gemt succesfuldt',
        'report_id' => $report_id
    ]);
}
?>